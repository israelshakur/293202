<?php
include "config/config.php";

security();

    if(isset($_GET['sair'])){
	if($_GET['sair'] == 'ok'){
		session_destroy();
		header('Location: login.php');
	}
}
?>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="photo/favicon.ico">

    <title>Home.</title>

    <!-- Principal CSS do Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
    <!-- Estilos customizados para esse template -->
    <style type="text/css">
    html,
    body {
    overflow-x: hidden; /* Previne rolagem, em dispositivos estreitos */
    background:#00000;
    color:#3498db;
    font-family: sans-serif;
    }
    
    body {
    padding-top: 45px;
    }
    
    @media (max-width: 991.98px) {
    .offcanvas-collapse {
    position: fixed;
    top: 56px; /* Altura da navbar */
    bottom: 0;
    left: 100%;
    width: 100%;
    padding-right: 1rem;
    padding-left: 1rem;
    overflow-y: auto;
    visibility: hidden;
    background-color: #333333;
    transition-timing-function: ease-in-out;
    transition-duration: .3s;
    transition-property: left, visibility;
    }
    .offcanvas-collapse.open {
    left: 0;
    visibility: visible;
    }
    }
    
    .nav-scroller {
    position: relative;
    z-index: 2;
    height: 2.75rem;
    overflow-y: hidden;
    }
    
    .nav-scroller .nav {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: nowrap;
    flex-wrap: nowrap;
    padding-bottom: 1rem;
    margin-top: -1px;
    overflow-x: auto;
    color: rgba(255, 255, 255, .75);
    text-align: center;
    white-space: nowrap;
    -webkit-overflow-scrolling: touch;
    }
    
    .nav-underline .nav-link {
    padding-top: .75rem;
    padding-bottom: .75rem;
    font-size: .875rem;
    color: #6c757d;
    }
    
    .nav-underline .nav-link:hover {
    color: #007bff;
    }
    
    .nav-underline .active {
    font-weight: 500;
    color: #343a40;
    }
   
    .text-white-50 { color: rgba(255, 255, 255, .5); }
    
    .bg-purple { background-color: #6f42c1; }
    
    .lh-100 { line-height: 1; }
    .lh-125 { line-height: 1.25; }
    .lh-150 { line-height: 1.5; }
    
    textarea{
    	border:2px solid #3498db;
    	border-radius:3px;
    	background:none;
    	outline: 0; 
    	width:100%;
    	text-align:center;
    }
    .bg-none{
    border:2px solid #3498db;
    border-radius:3px;
    background:none;
    outline: 0; 
    }
    .bg-darks{
    border:2px solid #3498db;
    border-radius:3px;
    background:#333333;
    outline: 0; 
    }
    .btn{
    background:none;
    border:2px solid #3498db;
    color:#3498db;
    }
    .fonte{
    font-family:sans-serif;
    }
    </style>
  </head>

  <body class="">

    <nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-darks">
      <a class="navbar-brand mr-auto mr-lg-1" href="#"> <?php echo $config['nomesite']; ?> </a>
      <button class="navbar-toggler p-0 border-0" type="button" data-toggle="collapse" data-target="#textoNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="textoNavbar">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="?sair=ok">Logout <span class="sr-only">(atual)</span></a>
          </li>
        </ul>
      </div>
    </nav>
    
    <div class="nav-scroller bg-none shadow-sm">
      <nav class="nav nav-underline">
      	<?php
      		$types = array('php');
      		if ($handle = opendir('apis')) {
      			while ( $entry = readdir( $handle )) {
      				$ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION) );
      				if( in_array($ext,$types)) 
      					echo '<a class="nav-link" href="#" onclick="javascript:return LoadChecker(\''.$entry.'\');">'.str_replace(".php","",str_replace("_"," ",$entry)).'</a>';
      			}
      			closedir($handle);
      		}    
      	?>
      </nav>
    </div>

    <main role="main" class="container">

      <div class="my-3 p-3 bg-none rounded shadow-sm">
        <center><h5 class="pb-1 mb-0" id="namechk">Checker</h5></center>
        <div class="media text-muted pt-3">
          <textarea class="" rows="9" id="list" placeholder="Cole sua db aqui..." ></textarea>
        </div> 
        <small class="d-block text-right mt-3">
          <center><button class="btn" id="start">Iniciar</button></center>
        </small>
      </div>

      <div class="my-3 p-3 bg-none rounded shadow-sm">
        <center><h6 class="pb-0 mb-0">Lives <span class="badge badge-pill bg-light align-text-bottom" id="live">0</span></h6></center>
        <div class="media text-muted pt-3">
         	<textarea class="" id="aprovadas" rows="6" disabled="disabled" ></textarea>
        </div>
      </div>
      
      <div class="my-3 p-3 bg-none rounded shadow-sm">
      	<center><h6 class="pb-0 mb-0">Dies <span class="badge badge-pill bg-light align-text-bottom" id="die">0</span></h6></center>
      	<div class="media text-muted pt-3">
      		<textarea class="" id="reprovadas" rows="6" disabled="disabled" ></textarea>
      	</div>
      </div>
    </main>

    <!-- Principal JavaScript do Bootstrap
    ================================================== -->
    <!-- Foi colocado no final para a página carregar mais rápido -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  	<script>	
  	var urlchk = "";
  	
  	function LoadChecker(api) {
  		urlchk = api;
  		var nomechk = api.replace(".php", " ");
  		var nomechk = nomechk.replace("_", " ");
  		document.getElementById("namechk").innerHTML = nomechk;
  		return false;
  	}
  	
	$(document).ready(function () {
	
		$('#start').attr('disabled', null);
		$('#start').click(function () {
			
			if(empty(urlchk)){
				alert('Escolha um chk no canto superior esquerdo');
				return false;
			}
			
			var line = $('#list').val().split('\n');
			var total = line.length;
			var ap = 0;
			var rp = 0;
			var sd = 0;
			line.forEach(function (value, index) {
				setTimeout(
					function () {				
						var ajaxCall = $.ajax({
							url: 'apis/'+urlchk,
							type: 'GET',
							data: 'lista=' + value,
							beforeSend: function () {
								$('#status').html('Testando!');
								$('#start').attr('disabled', 'disabled');
							},
							success: function (data) {
								if (data.indexOf("APROVADA") >= 0) {
									$("#aprovadas").val(data + "\n" + $("#aprovadas").val());
									ap = ap + 1;
									document.getElementById("aprovadas").innerHTML += data + "\n\n";
									removelinha();
								} else {
									$("#reprovadas").val(data + "\n" + $("#reprovadas").val());
									rp = rp + 1;
									document.getElementById("reprovadas").innerHTML += data + "\n";
									removelinha();
								};
	
								var fila = parseInt(ap) + parseInt(rp);
								$('#live').html(ap);
								$('#die').html(rp);
								//$('#testadas').html(fila);
								if (fila == total) {
									$('#start').attr('disabled', null);
									$('#status').html('Teste Finalizado!');
								}
							}
						})
					}, 1000 * index);
			});
		});
	});
  	
  	function removelinha() {
  		var lines = $("#list").val().split('\n');
  		lines.splice(0, 1);
  		$("#list").val(lines.join("\n"));
  	}
  	
  	function empty(data){
  		if(typeof(data) == 'number' || typeof(data) == 'boolean'){ 
  			return false; 
		}
  		if(typeof(data) == 'undefined' || data === null){
  			return true; 
  		}
  		if(typeof(data.length) != 'undefined'){
  			return data.length == 0;
  		}
  		var count = 0;
  		for(var i in data){
  			if(data.hasOwnProperty(i)){
  				count ++;
  			}
  		}
  		return count == 0;
  	}
  	</script>
  </body>
</html>