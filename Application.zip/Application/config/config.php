<?php

session_start();

function security(){
	if($_SESSION['logado'] == true ){

	}else{ 
		header('Location: login.php');
    
    }

}